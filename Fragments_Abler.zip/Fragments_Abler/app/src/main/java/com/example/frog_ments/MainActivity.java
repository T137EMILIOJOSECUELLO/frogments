package com.example.frog_ments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction; // Corrected import

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.FrameLayout;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    FrameLayout frim;
    TabLayout tablayout;

    @SuppressLint("SuspiciousIndentation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frim = findViewById(R.id.frim);
        tablayout = findViewById(R.id.tablayout);


            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.frim, new Fragment())
                    .addToBackStack(null)
                    .commit();

            tablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

                @Override
                public void onTabSelected(TabLayout.Tab tab) {

                    androidx.fragment.app.Fragment fragment = null;
                    switch (tab.getPosition()) {
                        case 0:
                            fragment = new Fragment();
                            break;
                        case 1:
                            fragment = new Fragment2();
                            break;
                        case 2:
                            fragment = new Fragment3();
                            break;
                        case 3:
                            fragment = new FragmentAll();
                            break;
                    }




                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.frim, fragment)
                            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                            .commit();

                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {

                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {

                }
            });
        }
    }
